# ch347 Windows Driver

## Driver Operating Overview

1. Double click "CH341PAR.EXE"
2. Click to install
3. Wait for installation to complete

4. Perform the same operations to install "CH343SER.exe"
5. Both drivers need to be installed
